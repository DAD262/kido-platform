package pe.edu.upeu.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KidoGatewayApplicationTests {
    @Test
    void contextLoads() {
    }
}
